import { Component } from '@angular/core';
import { Todos } from '../models/todos';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  readonly viewTitle:String = "Todo Lists"
  todos: Todos[] = [
    {
      id:1,
      title: 'Todo 1',
      description: `Special title treatment
      With supporting text below as a natural lead-in to additional content.`,
      isEditMode:false
    },

    {
      id:2,
      title: 'Todo 2',
      description: `Special title treatment
      With supporting text below as a natural lead-in to additional content.`,
      isEditMode:false
    },
    {
      id:3,
      title: 'Todo 3',
      description: `Special title treatment
      With supporting text below as a natural lead-in to additional content.`,
      isEditMode:false
    },
    {
      id:4,
      title: 'Todo 4',
      description: `Special title treatment
      With supporting text below as a natural lead-in to additional content.`,
      isEditMode:false
    }
  ];
}
