export class UserRequest {
    name?:String;
    userName?:String;
    emailId?:String;
    password?:String;
    confirmPassword?:String;
}
