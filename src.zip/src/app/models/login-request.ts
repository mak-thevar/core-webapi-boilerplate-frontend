export class LoginRequest {
    username?:String;
    password?:String;
}
