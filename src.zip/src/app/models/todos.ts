export class Todos {
    id?:number;
    title?:String;
    description?:String;
    isEditMode?:boolean;
}
